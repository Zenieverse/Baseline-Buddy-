import React, { useEffect, useState } from "react";
import { features } from "web-features";

function App() {
  const [unsupported, setUnsupported] = useState<string[]>([]);

  useEffect(() => {
    // Demo: pretend repo content is scanned
    const repoCode = `document.startViewTransition();`;
    const badFeatures = features.filter(f => repoCode.includes(f.name) && !f.status.baseline);
    setUnsupported(badFeatures.map(f => f.name));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Baseline Buddy Dashboard</h1>
      <p>Unsupported Features in Repo:</p>
      <ul>
        {unsupported.length === 0 ? <li>✅ All clear!</li> : unsupported.map(f => <li key={f}>⚠️ {f}</li>)}
      </ul>
    </div>
  );
}

export default App;
