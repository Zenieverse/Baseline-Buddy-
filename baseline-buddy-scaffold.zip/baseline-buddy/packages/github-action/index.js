const core = require("@actions/core");
const fs = require("fs");
const { features } = require("web-features");

async function run() {
  try {
    const files = fs.readdirSync("./src");
    let failed = false;

    for (const file of files) {
      const content = fs.readFileSync(`./src/${file}`, "utf-8");
      for (const feature of features) {
        if (content.includes(feature.name) && !feature.status.baseline) {
          core.warning(`Unsupported feature found in ${file}: ${feature.name}`);
          failed = true;
        }
      }
    }

    if (failed) core.setFailed("Unsupported features detected by Baseline Buddy");
  } catch (error) {
    core.setFailed(error.message);
  }
}

run();
