import * as vscode from "vscode";
import { features } from "web-features";

export function activate(context: vscode.ExtensionContext) {
  const diagnosticCollection = vscode.languages.createDiagnosticCollection("baseline");
  context.subscriptions.push(diagnosticCollection);

  vscode.workspace.onDidOpenTextDocument((doc) => checkDocument(doc, diagnosticCollection));
  vscode.workspace.onDidSaveTextDocument((doc) => checkDocument(doc, diagnosticCollection));
}

function checkDocument(doc: vscode.TextDocument, diagnostics: vscode.DiagnosticCollection) {
  if (doc.languageId !== "javascript" && doc.languageId !== "html" && doc.languageId !== "css") return;

  const diagnosticsList: vscode.Diagnostic[] = [];

  const text = doc.getText();
  for (const feature of features) {
    if (text.includes(feature.name) && !feature.status.baseline) {
      const index = text.indexOf(feature.name);
      const range = new vscode.Range(doc.positionAt(index), doc.positionAt(index + feature.name.length));
      diagnosticsList.push(new vscode.Diagnostic(range, `Feature "${feature.name}" is not in Baseline yet`, vscode.DiagnosticSeverity.Warning));
    }
  }

  diagnostics.set(doc.uri, diagnosticsList);
}

export function deactivate() {}
