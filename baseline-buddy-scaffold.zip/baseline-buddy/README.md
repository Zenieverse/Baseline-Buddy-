# Baseline Buddy

Baseline Buddy is a developer-first toolkit that integrates **Baseline web feature data** directly into IDEs, linters, and CI/CD pipelines.

## Features
- **VS Code Extension**: Highlights unsupported web features with hover tooltips.
- **ESLint Plugin**: Linting rules for detecting unsupported features.
- **GitHub Action**: Blocks PRs that use features not in Baseline.
- **Dashboard**: Visual overview of unsupported features in your repo.
- **CLI (planned)**: `npx baseline-check ./src`

## Tech Stack
- TypeScript, Node.js, React, ESLint, VS Code Extension API, GitHub Actions
- Data source: [web-features npm package](https://www.npmjs.com/package/web-features)

## License
MIT
